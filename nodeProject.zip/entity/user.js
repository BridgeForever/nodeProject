function User() {
    this.id;
    this.username;
    this.password;
}
module.exports = User;