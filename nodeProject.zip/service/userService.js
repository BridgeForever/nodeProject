var UserDao = require('../dao/userDao.js');

function UserService() {
    this.addUser = function(params) {
        var userDao = new UserDao();
        userDao.addUser();
    }
}
module.exports = UserService;