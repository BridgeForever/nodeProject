var express = require('express');
var router = express.Router();
var URL = require('url');
var UserService = require('../service/userService.js');
var User = require('../entity/user.js');
router.get('/', function(req, res, next) {
    res.send('respond with a resource');
});
router.get('/addUser', function(req, res, next) {
    var params = URL.parse(req.url, true).query;
    var userService = new UserService();
    userService.addUser(params);

    var response = { status: 1, data: { name: '11', 'age': '12' } };
    res.send(JSON.stringify(response));

})
module.exports = router;