var Db = require('../common/db.js');
var User = require('../entity/user.js');
var mysql = require('mysql');

function UserDao() {
    this.addUser = function(params) {
        var sql = 'INSERT INTO user(id, username,password) VALUES(?,?,?)';
        var addsqlparams = ['2222222', '小明 ', ' 123456 '];
        var db = new Db();
        var connection = db.connection;
        connection.connect(function(err) {
            if (err) {
                console.log('数据库连接失败' + err);
                return;
            }
        });
        connection.query(sql, addsqlparams, function(err, result) {
            if (err) {
                console.log('添加用户失败' + err);
                return;
            }
            console.log('.....新增成功.......');
            console.log(result);
            console.log('.....新增结束......');

        })
        connection.end();
    };
    this.modifyUser = function() {

    };
    this.deleteUser = function() {

    };
    this.findUser = function() {

    }
}
module.exports = UserDao;