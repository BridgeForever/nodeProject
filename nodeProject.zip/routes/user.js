function User() {
    this.name;
    this.city;
    this.age;
}
module.exports = User;